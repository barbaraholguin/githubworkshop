from student1 import mydivisible7not5

print(mydivisible7not5(5))
