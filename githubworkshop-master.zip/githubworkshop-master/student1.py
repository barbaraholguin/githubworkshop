
def mydivisible7not5(N):
  return(int(N)%7==0 and int(N)%5!=0)
